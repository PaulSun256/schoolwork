javac Prime2.java
java Prime2

# keeps window open till a key is pressed
echo
read -rsn1 -p "Press any key to continue..."