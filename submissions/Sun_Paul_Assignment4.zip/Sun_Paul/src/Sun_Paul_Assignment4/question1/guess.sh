javac guess.java
java Guess

# keeps window open till a key is pressed
echo
read -rsn1 -p "Press any key to continue..."