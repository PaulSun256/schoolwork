javac PrimeFactor.java
java PrimeFactor

# keeps window open till a key is pressed
echo
read -rsn1 -p "Press any key to continue..."