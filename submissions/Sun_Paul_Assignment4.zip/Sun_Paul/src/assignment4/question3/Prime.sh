javac Prime.java
java Prime

# keeps window open till a key is pressed
echo
read -rsn1 -p "Press any key to continue..."