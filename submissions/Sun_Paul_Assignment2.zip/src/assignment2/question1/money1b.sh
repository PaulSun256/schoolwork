javac money1b.java
java Money

# keeps window open till a key is pressed
echo
read -rsn1 -p "Press any key to continue..."