/*
+========================================+
|              Assignment 1              |
+========================================+
|          Paul Sun, 2020/09/18          |
+========================================+
|               ICS3U Ms.S               |
+========================================+
|    First assignment, prints out Bart   |
|  Simpson and my name in ASCII art form |
+========================================+
*/

// follow me on github because i want followers
// https://github.com/PaulSun256/

class Bart  {
  public static void main(String[] args)  {
    
    // prints out ascii of Bart from The Simpsons
    System.out.print(
    "  |\\/\\/\\/|\n"+
    "  |      |\n"+
    "  |      |\n"+
    "  | (o)(o)\n"+
    "  C      _)\n"+
    "  | ,___|\n"+
    "  |   /\n"+
    " /____\\\n"+
    "/      \\\n\n");

    // ascii art for my name, Paul Sun
    System.out.print(
    " _____            _    _____\n"+
    "|  __ \\          | |  / ____|\n"+
    "| |__) |_ _ _   _| | | (___  _   _ _ __\n"+
    "|  ___/ _` | | | | |  \\___ \\| | | | '_ \\\n"+
    "| |  | (_| | |_| | |  ____) | |_| | | | |\n"+
    "|_|   \\__,_|\\__,_|_| |_____/ \\__,_|_| |_|");
  }
}

