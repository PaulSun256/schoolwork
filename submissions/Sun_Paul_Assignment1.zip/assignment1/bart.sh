javac bart.java
java Bart
echo
read -rsn1 -p "Press any key to continue..."